PETPULSE - Pet Care and Information System   (Java Swing / NetBeans / MySQL)
Green and white theme - Trash Bin is now "Archive" - MySQL database included
=============================================================================

1) OPEN IN NETBEANS
   File > Open Project > select the "PetPulse" folder (it shows a Maven icon) > Open.
   First time: wait for NetBeans to download the MySQL driver (needs internet once).
   If it asks to "Resolve problems", click Resolve / right-click project > Build.

2) START MYSQL
   XAMPP: open the XAMPP Control Panel > Start "MySQL".
   (MySQL Workbench / WAMP / Laragon also work.)

3) RUN
   Right-click the project > Run  (or press F6).
   The database "petpulse_db" and all tables are created automatically.
   Default login:   username  admin      password  admin123

   Wrong MySQL user/password/port?  On the login screen click "Database Settings",
   type them, press "Test Connection", then "Save".
   (Or edit src/main/resources/db.properties.)

4) EDIT THE DESIGN (drag and drop)
   Open  src/main/java/petpulse/ui  and double-click:
      LoginFrame.java      -> click the "Design" tab
      MainFrame.java       -> sidebar + top bar
      DashboardPanel.java  -> welcome text + the 4 counters
   (Pet Information, Appointments, Vaccinations, Payments, Archive screens are built
    by CrudPanel.java / ReportPanel.java / ArchivePanel.java - edit them as code.)

5) CHANGE THE LOGO
   Replace   src/main/resources/petpulse/resources/logo.png   with the client's logo
   (PNG, ideally square). Login screen, sidebar and window icon update automatically.

6) CHANGE THE COLORS
   All colors are in src/main/java/petpulse/util/Theme.java
   (the .form files use the same green values).

7) MAKE A RUNNABLE .JAR
   Right-click project > Clean and Build  ->  target/PetPulse-1.0.jar
   Run with:  java -jar PetPulse-1.0.jar   (MySQL must be running)

8) MANUAL DATABASE (optional)
   database/schema.sql can be imported in phpMyAdmin / MySQL Workbench.

9) HISTORY TABLES (new)
   transaction_history  - one row per payment event. It stores its OWN copy of the pet and
                          owner name and has no foreign key, so the history is kept even if the
                          pet or payment is deleted permanently.
   archive_log          - one row per archive / restore / permanent delete of any record.
   9 triggers fill both tables automatically, so they stay correct however data is changed.
   "Archive" itself = the archived / archived_at columns (soft delete, restorable).
   Upgrading an existing database: just run the new version once. The new tables and triggers
   are added and your old payments / archived records get a first history row.
   The triggers need the MySQL TRIGGER privilege (root on XAMPP has it). If they cannot be
   created, the login screen shows a red warning (hover for the reason).

SCREENS
   Dashboard | Pet Information | Appointments | Vaccinations | Payments |
   Transaction History | Pet Records | Archive | Logout
   - Add / Edit / Archive on every data screen (double-click a row to edit).
   - Archive screen: Restore or Delete Permanently. The "Archive Log" button shows who
     archived / restored / permanently deleted what, and when.
   - Transaction History: a ledger of every payment event (PAID, EDITED, ARCHIVED, RESTORED,
     DELETED) with date, time and the user who did it. The search box filters it
     (type e.g. DELETED or a pet name).
   - Dashboard numbers and "Today's Appointments" update after every change.

PROBLEMS?
   "MySQL JDBC driver not found"  -> right-click project > Build (internet needed once),
                                     or Libraries > Add Library > "MySQL JDBC Driver".
   "Communications link failure"  -> MySQL is not running or the port is not 3306.
   "Access denied"                -> wrong user/password in Database Settings.
