package petpulse;

import petpulse.ui.LoginFrame;
import petpulse.util.Theme;

/** Program entry point. In NetBeans: right-click project > Run (F6). */
public class Main {
    public static void main(String[] args) {
        Theme.installLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
