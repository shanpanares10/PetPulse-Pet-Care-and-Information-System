package petpulse.ui;

/** Implemented by every screen that can reload its data from the database. */
public interface Refreshable {
    void refresh();
}
